这个是fork的https://github.com/initialxy/cordova-plugin-themeablebrowser做的二次开发 用于全屏和非全屏页面切换
