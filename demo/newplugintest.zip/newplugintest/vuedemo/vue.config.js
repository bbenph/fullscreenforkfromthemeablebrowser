const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');

// vue.config.js
module.exports = {
    publicPath: '',
    // 当运行 vue-cli-service build 时生成的生产环境构建文件的目录 Default: 'dist'
    // Node.js 中， __dirname 总是指向被执行js 文件的绝对路径
    outputDir: path.resolve(__dirname, '../www'),
    // 指定生成的 index.html 的输出路径 (相对于 outputDir)。也可以是一个绝对路径。Default: 'index.html'
    indexPath: 'index.html',
    // 放置生成的静态资源 (js、css、img、fonts) 的 (相对于 outputDir 的) 目录 Default: ''
    assetsDir: '',

    // configureWebpack: {
    //     plugins: [
    //         new CopyWebpackPlugin({
    //             patterns: [
    //                 {
    //                     from: path.join(__dirname, 'static/browserIcons'),
    //                     to: path.join(__dirname, '../www/browserIcons'),
    //                     toType: "dir"
    //                 },
    //             ],
    //         }),
    //     ],
    // }

}