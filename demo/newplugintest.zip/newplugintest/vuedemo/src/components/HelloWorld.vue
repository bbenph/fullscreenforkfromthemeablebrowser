<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <button @click="openAppBrowser('https://m.office68.com/zt/nnqp/','页面1','PORTRAIT')">跳转页面1</button>
    <button @click="openAppBrowser('https://www.qq.com/','页面2','LANDSCAPE')">跳转页面2</button>

  </div>
</template>

<script>
import {openAppBrowser} from '../appBrowser.js'
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },
  data() {
    return {
    };
  },
  methods: {
    openAppBrowser
  },
};
</script>