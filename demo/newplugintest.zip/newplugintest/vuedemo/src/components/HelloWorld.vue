<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <button @click="openAppBrowser('https://m.office68.com/zt/nnqp/','页面1','AUTO')">自动横竖屏</button>
    <button @click="openAppBrowser('https://qq.com','页面2','PORTRAIT')">强制竖屏</button>
    <button @click="openAppBrowser('https://github.com','页面3','LANDSCAPE')">强制横屏</button>

  </div>
</template>

<script>
import {openAppBrowser} from '../appBrowser.js'
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },
  data() {
    return {
    };
  },
  methods: {
    openAppBrowser
  },
};
</script>