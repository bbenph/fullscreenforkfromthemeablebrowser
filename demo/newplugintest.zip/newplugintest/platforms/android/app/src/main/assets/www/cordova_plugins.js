cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-fullscreenforkfromthemeablebrowser.themeablebrowser",
      "file": "plugins/cordova-plugin-fullscreenforkfromthemeablebrowser/www/themeablebrowser.js",
      "pluginId": "cordova-plugin-fullscreenforkfromthemeablebrowser",
      "clobbers": [
        "cordova.ThemeableBrowser"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-fullscreenforkfromthemeablebrowser": "0.0.6"
  };
});